import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  //styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  birthday = new Date(1993, 8, 30); // August 30 1993
}
